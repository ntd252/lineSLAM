﻿function book(courtId, hour) {
    $("#hour").val(hour);
    //$("#bookNow").click();
    $("#bookingPanel").collapse('show');
}