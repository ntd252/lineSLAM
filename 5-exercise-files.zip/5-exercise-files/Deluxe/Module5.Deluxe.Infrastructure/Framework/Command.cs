﻿namespace Module5.Deluxe.Infrastructure.Framework
{
    public class Command : Message
    {
    }
}